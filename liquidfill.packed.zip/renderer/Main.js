define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var e=function(){function t(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}return t.prototype.getName=function(){return this.name},t.prototype.getSlot=function(){return this.slot},t.prototype.getAttributes=function(){return this.attributes},t.slotLimit=function(e,n){return new t("limit",e).attr("n",n)},t.dataLimit=function(e){return new t("limit").attr("n",e)},t.prototype.attr=function(t,e){return this.attributes.set(t,e),this},t}(),n=function(t,e){return (n=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e;}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);})(t,e)};function r(t,e){function r(){this.constructor=t;}n(t,e),t.prototype=null===e?Object.create(e):(r.prototype=e.prototype,new r);}function o(t,e,n){return t.getDecoration(e,n)}function i(t){return t.hasDecoration("hasSelection")?o(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}var u,s=function(){function t(t,e){this.min=t,this.max=e;}return t.prototype.asArray=function(){return [this.min,this.max]},t.empty=new t(0,0),t}(),a=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e.fromRS=function(t){return new s(t.min,t.max)},e}(s),l=function(){function t(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),c=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(l),h=new(function(){function t(){}return t.prototype.format=function(t){return t?t.toString():""},t}());!function(t){t.label="label",t.data="data";}(u||(u={}));var p=function(){function t(t,e,n,r){this.source=t,this.tuples=e,this.domain=n,this.caption=r;var o=t.dataItems||[],i=o.length>0?o[0]:null,u=i&&i.asCont();u?(this._labelFormatter=u.getFormatter("label")||h,this._dataFormatter=u.getFormatter("data")||h):this._labelFormatter=this._dataFormatter=h;}return Object.defineProperty(t.prototype,"mapped",{get:function(){return this.source.mapped},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"dataType",{get:function(){var t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"},enumerable:!0,configurable:!0}),t.prototype.format=function(t,e){return function(t,e){return t.format(e)}(e===u.data?this._dataFormatter:this._labelFormatter,t)},t}(),f=function(t){function e(e,n,r,o){return t.call(this,e,n,r,o)||this}return r(e,t),e}(p),g=function(){function t(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t.prototype.tuple=function(t){var e=this._getSlot(t);if(!e||0===e.tuples.length)return null;var n=this.source.get(e.source);if(!n)return null;var r=n.asCat();return r?e.tuples[r.index]:null},t.prototype.value=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);if(!n)return null;var r=n.asCont();return r&&"numeric"===r.valueType?r.value:null},t.prototype.caption=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);return n&&n.getCaption("data")||""},t.prototype._getSlot=function(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null},t}(),d=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(g),y=function(){function t(t,e,n){var r=this;this.source=t,this.rows=t.dataPoints.map(function(t){return new d(t,r)}),this.cols=e,this.slotMap=n;}return t.filterRows=function(t,e,n){return t.filter(function(t){var r=t.tuple(e);return !!r&&r.key===n})},Object.defineProperty(t.prototype,"hasSelections",{get:function(){return i(this.source)},enumerable:!0,configurable:!0}),t}(),m=function(t){function e(e,n,r){return t.call(this,e,n,r)||this}return r(e,t),e}(y);function v(t){var e=new Map,n=t.getSlots().map(function(t,n){var r=[],o=s.empty,i="";if(t.isMapped()){var u=t.getDataItem(0);i=u.getCaption("label"),"cat"===u.getRSType()?r=u.getTuples().map(function(t,e){return new c(t,e)}):o=a.fromRS(u.getDomain());}var l=new f(t,r,o,i);return e.set(t.name,l),l});return new m(t,n,e)}function _(t){return t<0?0:t>255?255:Math.floor(t)}var b=function(){function t(t,e,n,r){var o;this.r=_(t),this.g=_(e),this.b=_(n),this.a=(o=r)<0?0:o>1?1:o;}return t.fromObject=function(e){return new t(e.r,e.g,e.b,void 0===e.a?1:e.a)},t.prototype.toString=function(){return 1===this.a?"rgb("+this.r+","+this.g+","+this.b+")":"rgba("+this.r+","+this.g+","+this.b+","+this.a+")"},t}();function w(t,e){var n=null;if(t instanceof g)n=t.source.getDataSet(e);else{var r=t.source.getDataItem(e);n=r&&r.getDataSet(e);}return !!n&&i(n)}var C=function(t){return "rgba("+t.r+","+t.g+","+t.b+",0.4)"},S=function(t){return "rgba("+.7*t.r+","+.7*t.g+","+.7*t.b+","+t.a+")"},P=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColor=function(t){return t?b.fromObject(this.source.getTupleColor(t.source,-1)):b.fromObject(this.source.getColor(null))},t.prototype._getTuple=function(t){if(t instanceof l)return t;var e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null},t.prototype.getFillColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),!t.selected&&w(t,this._dataContext)?C(e):e.toString()},t.prototype.getOutlineColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&w(t,this._dataContext)?S(e):null},t}(),j=function(){return function(t,e,n){this.color=t,this.at=e,this.value=n;}}();function O(t){return t.map(function(t){return new j(b.fromObject(t.color),t.at,t.value)})}var x=function(){function t(t,e,n){this.source=t,this._slot=e,this._dataContext=n,this.stops=O(t.stops),this.aligned=O(t.aligned),this.interpolate=t.interpolate;}return t.prototype.getColor=function(t){return b.fromObject(this.source.getColor(t))},t.prototype.getFillColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return !t.selected&&w(t,this._dataContext)?C(n):n.toString()},t.prototype.getOutlineColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return t.highlighted||t.selected&&w(t,this._dataContext)?S(n):null},t}(),D=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColorStops=function(t){var e=t?t.source.getDataItem(0):null,n=e&&e.asCont(),r=n?n.getDomain(null):null,o=this.source.getColorStops(n,r),i=t?t.source.name:null;return new x(o,i,this._dataContext)},t.prototype._fetchColorStops=function(t){var e=t.source.getDataSet(this._dataContext),n=this.slot||this._slotResolver(t.dataSet,this.source.name),r=n?e.getSlot(n):null,o=r?r.getDataItem(0):null,i=o?o.asCont():null;if(this.source.dirty||!this._cachedStops||i!==this._lastDataItem){var u=i?i.getDomain(null):null,s=this.source.getColorStops(i,u);this._cachedStops=new x(s,r&&r.name,this._dataContext),this._lastDataItem=i;}return this._cachedStops},t.prototype.getFillColor=function(t){return this._fetchColorStops(t).getFillColor(t)},t.prototype.getOutlineColor=function(t){return this._fetchColorStops(t).getOutlineColor(t)},t}(),I=function(t){function e(e){var n=t.call(this,e.r,e.g,e.b,e.a)||this;return n._color=e,n}return r(e,t),e.prototype.getRed=function(){return this.r},e.prototype.getGreen=function(){return this.g},e.prototype.getBlue=function(){return this.b},e.prototype.getAlpha=function(){return this.a},e}(b),E=function(){function t(t,e,n,r,o,i){this.caption=t,this.color=e,this.shape=n,this.selected=r,this.highlighted=o,this.ref=i;}return t.prototype.getCaption=function(){return this.caption},t.prototype.getColor=function(){return this.color?new I(this.color):null},t.prototype.getShape=function(){return this.shape},t.prototype.isSelected=function(){return this.selected},t.prototype.isHighlighted=function(){return this.highlighted},t.prototype.getRef=function(){return this.ref},t}(),T=function(){function t(t,e,n,r,o,i){this.type=t,this.channel=e,this.slot=n,this.caption=r,this.subCaption=o,this.ref=i;}return t.prototype.getRSType=function(){return this.type},t.prototype.getChannel=function(){return this.channel},t.prototype.getSlot=function(){return this.slot},t.prototype.getCaption=function(){return this.caption},t.prototype.getSubCaption=function(){return this.subCaption},t.prototype.getRef=function(){return this.ref},t}(),R=function(t){function e(e,n,r,i,u){var s=this,a=n&&n.source,l=a&&a.name,c=a&&a.getDataItem(0),h=c&&c.asCat();s=t.call(this,"cat",e,l,r,"",h)||this;var p=h?h.tuples:[];return s.entries=p.map(function(t){var e=t.getCaption("label")||"",n=u&&u.source.getTupleColor(t,-1),r=o(t,"selected",!1),s=o(t,"highlighted",!1);return new E(e,n?b.fromObject(n):null,i,r,s,t)}),s}return r(e,t),e.prototype.getEntries=function(){return this.entries},e}(T),F=function(t){function e(e,n,r,o){var i=this,u=n&&n.source,s=u&&u.name,a=u&&u.getDataItem(0),l=a&&a.asCont();if((i=t.call(this,"cont",e,s,r,"",l)||this).domain=l&&l.getDomain(null),o&&"color"===e){var c=o.source.getColorStops(l,null);i.stops=c.stops,i.interpolate=c.interpolate;}else i.stops=null,i.interpolate=!1;return i}return r(e,t),e.prototype.getDomain=function(){return this.domain},e.prototype.getInterpolate=function(){return this.interpolate},e.prototype.getStops=function(){return this.stops},e}(T);function L(t,e,n,r){if(!t)return [];var o=new Map,i=new Map;e.palettes.forEach(function(e){var n=e.slot||r&&r(t,e.source.name);n&&(e instanceof P?o.set(n,e):e instanceof D&&i.set(n,e));});var u=[];return t.cols.forEach(function(t){var e=t.source;if(e.mapped){var r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;var s=o.get(e.name);s&&u.push(new R("color",t,t.caption,n.legendShape,s));break;case"cont":if(-1!==e.channels.indexOf("color")){var a=i.get(e.name);a&&u.push(new F("color",t,t.caption,a));}-1!==e.channels.indexOf("size")&&u.push(new F("size",t,t.caption,null));}}}),u}var A,M=function(){return function(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;}}();!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(A||(A={}));var N,k,B=function(){function t(t,e){this.value=t,this.unit=e;}return t.fromObject=function(e){return new t(e.value,function(t){switch(t){case"em":return A.Em;case"%":return A.Percentage;case"cm":return A.Centimeter;case"mm":return A.Millimeter;case"in":return A.Inch;case"pc":return A.Pica;case"pt":return A.Point;case"px":return A.Pixel;default:throw new Error("Invalid length unit '"+t+"' specified")}}(e.unit))},t.prototype.toString=function(){return ""+this.value+this.unit},t}();!function(t){t.Normal="normal",t.Italic="italic";}(N||(N={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(k||(k={}));var H=/\s+/g;function V(t){switch(t){case k.Normal:return "normal";case k.Bold:return "bold";case k.Thin:case k.ExtraLight:case k.Light:case k.Medium:case k.SemiBold:case k.ExtraBold:case k.Heavy:return t.toString();default:return ""}}function U(t){var e=[];if(t)for(var n=0,r=t.length;n<r;++n){var o=t[n],i=H.test(o);e.push(i?'"'+o+'"':o);}return e.join(", ")}var q=function(){function t(t,e,n,r){this.family=t,this.size=e,this.style=n,this.weight=r;}return t.fromObject=function(e){return new t(e.family||null,e.size?B.fromObject(e.size):null,e.style?function(t){switch(t){case"normal":return N.Normal;case"italic":return N.Italic;default:throw new Error("Invalid font style '"+t+"' specified")}}(e.style):null,void 0!==e.weight&&null!==e.weight?e.weight:null)},t.prototype.toString=function(){if(this.style!==N.Normal&&this.weight!==k.Normal||this.style===N.Normal&&this.weight===k.Normal){var t=[];return this.style===N.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(V(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(U(this.family)),t.join(" ")}return function(t){var e,n=[],r=U(t.family);return r.length>0&&n.push("font-family: "+r+";"),(r=t.size?t.size.toString():"").length>0&&n.push("font-size: "+r+";"),(r=(e=t.style)?e.toString():"").length>0&&n.push("font-style: "+r+";"),(r=V(t.weight)).length>0&&n.push("font-weight: "+r+";"),n.join(" ")}(this)},t}(),K=function(){function t(t,e,n){var r=new Map;null!==t&&t.forEach(function(t,o){if("palette"===t.type){var i=t;switch(i.paletteType){case"cat":r.set(o,new P(i,e,n));break;case"cont":r.set(o,new D(i,e,n));}}}),this.source=t,this.palettes=r;}return t.prototype.get=function(t){return this._getValue(t,!1)},t.prototype.peek=function(t){return this._getValue(t,!0)},t.prototype._getValue=function(t,e){var n=this.source&&this.source.get(t);if(!n)return null;switch(n.type){case"string":case"number":case"boolean":case"enum":return e?n.peek:n.value;case"length":var r=e?n.peek:n.value;return r?B.fromObject(r):null;case"font":var o=e?n.peek:n.value;return o?q.fromObject(o):null;case"color":var i=e?n.peek:n.value;return i?b.fromObject(i):null;case"palette":return this.palettes.get(t)||null;default:return null}},t.prototype.isActive=function(t){var e=this.source&&this.source.get(t);return !!e&&e.active},t.prototype.setActive=function(t,e){var n=this.source&&this.source.get(t);n&&n.setActive(e);},t.prototype.isDirty=function(t){var e=this.source&&this.source.get(t);return !!e&&e.dirty},t}();var G=setTimeout;function J(t){return Boolean(t&&void 0!==t.length)}function Q(){}function W(t){if(!(this instanceof W))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],et(t,this);}function X(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,W._immediateFn(function(){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var r;try{r=n(t._value);}catch(t){return void Z(e.promise,t)}Y(e.promise,r);}else(1===t._state?Y:Z)(e.promise,t._value);})):t._deferreds.push(e);}function Y(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var n=e.then;if(e instanceof W)return t._state=3,t._value=e,void $(t);if("function"==typeof n)return void et((r=n,o=e,function(){r.apply(o,arguments);}),t)}t._state=1,t._value=e,$(t);}catch(e){Z(t,e);}var r,o;}function Z(t,e){t._state=2,t._value=e,$(t);}function $(t){2===t._state&&0===t._deferreds.length&&W._immediateFn(function(){t._handled||W._unhandledRejectionFn(t._value);});for(var e=0,n=t._deferreds.length;e<n;e++)X(t,t._deferreds[e]);t._deferreds=null;}function tt(t,e,n){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=n;}function et(t,e){var n=!1;try{t(function(t){n||(n=!0,Y(e,t));},function(t){n||(n=!0,Z(e,t));});}catch(t){if(n)return;n=!0,Z(e,t);}}W.prototype.catch=function(t){return this.then(null,t)},W.prototype.then=function(t,e){var n=new this.constructor(Q);return X(this,new tt(t,e,n)),n},W.prototype.finally=function(t){var e=this.constructor;return this.then(function(n){return e.resolve(t()).then(function(){return n})},function(n){return e.resolve(t()).then(function(){return e.reject(n)})})},W.all=function(t){return new W(function(e,n){if(!J(t))return n(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var o=r.length;function i(t,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var s=u.then;if("function"==typeof s)return void s.call(u,function(e){i(t,e);},n)}r[t]=u,0==--o&&e(r);}catch(t){n(t);}}for(var u=0;u<r.length;u++)i(u,r[u]);})},W.resolve=function(t){return t&&"object"==typeof t&&t.constructor===W?t:new W(function(e){e(t);})},W.reject=function(t){return new W(function(e,n){n(t);})},W.race=function(t){return new W(function(e,n){if(!J(t))return n(new TypeError("Promise.race accepts an array"));for(var r=0,o=t.length;r<o;r++)W.resolve(t[r]).then(e,n);})},W._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){G(t,0);},W._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};var nt=function(){return function(t,e,n,r){this.data=t,this.decorations=e,this.properties=n,this.size=r;}}(),rt=function(){return function(t,e,n,r,o){this.reason=t,this.data=e,this.node=n,this.props=r,this.locale=o;}}();var ot=function(){function n(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new K(null,null,this._slotResolver),this.meta=new M;}return n.prototype.init=function(t,e){var n=this,r=t.surface.appendChild(document.createElement("div"));r.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),r.setAttribute("data-charttype","custom-viz"),this.properties=new K(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,W.resolve(this.create(r)).then(function(o){n._elem=o||r,t.properties.forEach(function(t,e){return n.updateProperty(e,t.value)}),e.complete();}).catch(function(t){e.fail(t);});},n.prototype.destroy=function(){},n.prototype.getPropertyApi=function(){return null},n.prototype.setData=function(t){t&&t.dataSets&&t.dataSets[0]?this._data=v(t.dataSets[0]):this._data=null;},n.prototype.setProperty=function(t,e){this.updateProperty(t,this.properties.peek(t));},n.prototype.getBlockingRequests=function(){return null},n.prototype.render=function(t,e,n){if(!this._elem)return n.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return n.complete(null,null,null),null;try{var r=this.update(new rt(function(t){return new nt(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));W.resolve(r).then(function(){return n.complete(null,null,null)}).catch(n.error);}catch(t){n.error(t);}return null},n.prototype.getEncodings=function(){return this._data?this.updateLegend(this._data):[]},n.prototype.getCapabilities=function(){var t=[];return this.meta.slotLimits.forEach(function(n,r){t.push(e.slotLimit(r,n));}),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t},n.prototype.getInteractivity=function(){return null},n.prototype.getVisCoordinate=function(t,e){return e},n.prototype.getRegionAtPoint=function(t,e){return null},n.prototype.getItemsAtPoint=function(t,e,n){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;var r=t,o=document.elementFromPoint(r.x,r.y),i=this.hitTest(o,r,e);return i&&i.source?[i.source]:[]},n.prototype.getItemsInPolygon=function(t,e){return []},n.prototype.getAxisItemsAtPoint=function(t,e,n){return []},n.prototype.getState=function(){return null},n.prototype.setState=function(t){},n.prototype.loadCss=function(t){var e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);},n.prototype.toUrl=function(e){return requirejs.toUrl(e)},n.prototype.update=function(t){},n.prototype.create=function(t){},n.prototype.updateProperty=function(t,e){},n.prototype.updateLegend=function(t){return L(t,this.properties,this.meta,this._slotResolver)},n.prototype.getSlotForPalette=function(t,e){return null},n.prototype.hitTest=function(t,e,n){var r=t&&t.__data__;return r&&r.source?r:null},n.prototype.nls=function(t){return this._nls&&this._nls.get(t)||""},n}();

    /**
     * Licensed Materials - Property of IBM
     *
     * Copyright IBM Corp. 2019 All Rights Reserved.
     *
     * US Government Users Restricted Rights - Use, duplication or
     * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
     */
    var default_1 = /** @class */ (function (_super) {
        __extends(default_1, _super);
        function default_1() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        // Create is called during initialization
        default_1.prototype.create = function (_node) {
            // Create SVG node return the container
            return d3.select(_node).append("svg")
                .attr("width", "100%")
                .attr("height", "100%")
                .node();
        };
        // Update is called during new data, property change, resizing, etc.
        default_1.prototype.update = function (_info) {
            var data = _info.data;
            var props = _info.props;
            //Assign ID to div. Random used to make it unique.
            var nodeid = Math.random().toString(36).substr(2, 9);
            _info.node.setAttribute('id', nodeid);
            var config1 = liquidFillGaugeDefaultSettings();
            //Override properties. Description of properties can be found under liquidFillGaugeDefaultSettings
            config1.minValue = props.get("min");
            config1.maxValue = props.get("calcPer") ? 100 : props.get("max");
            config1.circleColor = props.get("circle-color");
            config1.textColor = props.get("text-color");
            config1.waveTextColor = props.get("wave-text-color");
            config1.waveColor = props.get("wave-color");
            config1.circleThickness = props.get("thickness");
            config1.textVertPosition = props.get("textPosition");
            config1.waveAnimateTime = props.get("waveAnimationTime");
            config1.circleFillGap = props.get("fillGap");
            config1.waveHeight = 0.05;
            config1.waveCount = props.get("waveCount");
            config1.waveRiseTime = 1000;
            config1.waveRise = true;
            config1.waveHeightScaling = true;
            config1.waveAnimate = props.get("waveAnimation");
            config1.valueCountUp = true;
            config1.displayPercent = props.get("percentage");
            config1.opacity = props.get("fillOpacity");
            config1.font = props.get("labelFont").family;
            var fontSize = props.get("labelFont").size.value == 12 ? 0.5 : props.get("labelFont").size.value == 14 ? 1 : props.get("labelFont").size.value == 16 ? 1.5 : 2;
            config1.textSize = fontSize;
            var gauge1 = loadLiquidFillGauge(nodeid, props.get("calcPer") ? data.rows[0].value("value") * 100 / props.get("max") : data.rows[0].value("value"), config1, _info.node);
        };
        return default_1;
    }(ot));
    function liquidFillGaugeDefaultSettings() {
        return {
            minValue: 0,
            maxValue: 100,
            circleThickness: 0.05,
            circleFillGap: 0.05,
            circleColor: "#178BCA",
            waveHeight: 0.05,
            waveCount: 1,
            waveRiseTime: 100,
            waveAnimateTime: 180,
            waveRise: true,
            waveHeightScaling: true,
            waveAnimate: true,
            waveColor: "#178BCA",
            waveOffset: 0,
            textVertPosition: .5,
            textSize: 1,
            valueCountUp: true,
            displayPercent: true,
            textColor: "#045681",
            waveTextColor: "#A4DBf8",
            opacity: 0.5,
            font: "arial" //Text font
        };
    }
    function loadLiquidFillGauge(elementId, value, config, _node) {
        if (config == null)
            config = liquidFillGaugeDefaultSettings();
        var gauge = d3.select(_node);
        //Destory chart on each refresh
        gauge.selectAll("svg > *").remove();
        var w = gauge.style("width").replace('px', '');
        var h = gauge.style("height").replace('px', '');
        var radius = Math.min(w, h) / 2;
        var locationX = parseInt(w) / 2 - radius;
        var locationY = parseInt(h) / 2 - radius;
        var fillPercent = Math.max(config.minValue, Math.min(config.maxValue, value)) / config.maxValue;
        var waveHeightScale = null;
        if (config.waveHeightScaling) {
            waveHeightScale = d3.scaleLinear()
                .range([0, config.waveHeight, 0])
                .domain([0, 50, 100]);
        }
        else {
            waveHeightScale = d3.scaleLinear()
                .range([config.waveHeight, config.waveHeight])
                .domain([0, 100]);
        }
        var textPixels = (config.textSize * radius / 2);
        var textFinalValue = parseFloat(value).toFixed(2);
        var textStartValue = config.valueCountUp ? config.minValue : textFinalValue;
        var percentText = config.displayPercent ? "%" : "";
        var circleThickness = config.circleThickness * radius;
        var circleFillGap = config.circleFillGap * radius;
        var fillCircleMargin = circleThickness + circleFillGap;
        var fillCircleRadius = radius - fillCircleMargin;
        var waveHeight = fillCircleRadius * waveHeightScale(fillPercent * 100);
        var waveLength = fillCircleRadius * 2 / config.waveCount;
        var waveClipCount = 1 + config.waveCount;
        var waveClipWidth = waveLength * waveClipCount;
        // Rounding functions so that the correct number of decimal places is always displayed
        // as the value counts up.
        var format = d3.format(".0f");
        // Data for building the clip wave area.
        var data = [];
        for (var i = 0; i <= 40 * waveClipCount; i++) {
            data.push({ x: i / (40 * waveClipCount), y: (i / (40)) });
        }
        // Scales for drawing the outer circle.
        var gaugeCircleX = d3.scaleLinear().range([0, 2 * Math.PI]).domain([0, 1]);
        var gaugeCircleY = d3.scaleLinear().range([0, radius]).domain([0, radius]);
        // Scales for controlling the size of the clipping path.
        var waveScaleX = d3.scaleLinear().range([0, waveClipWidth]).domain([0, 1]);
        var waveScaleY = d3.scaleLinear().range([0, waveHeight]).domain([0, 1]);
        // Scales for controlling the position of the clipping path.
        var waveRiseScale = d3.scaleLinear()
            // The clipping area size is the height of the fill circle + the wave height,
            // so we position the clip wave such that the it will overlap the fill circle
            // at all when at 0%, and will totally cover the fill circle at 100%.
            .range([(fillCircleMargin + fillCircleRadius * 2 + waveHeight), (fillCircleMargin - waveHeight)])
            .domain([0, 1]);
        var waveAnimateScale = d3.scaleLinear()
            .range([0, waveClipWidth - fillCircleRadius * 2]) // Push the clip area one full wave then snap back.
            .domain([0, 1]);
        // Scale for controlling the position of the text within the gauge.
        var textRiseScaleY = d3.scaleLinear()
            .range([fillCircleMargin + fillCircleRadius * 2, (fillCircleMargin + textPixels * 0.7)])
            .domain([0, 1]);
        // Center the gauge within the parent SVG.
        var gaugeGroup = gauge.append("g")
            .attr('transform', 'translate(' + locationX + ',' + locationY + ')');
        // Draw the outer circle.
        var gaugeCircleArc = d3.arc()
            .startAngle(gaugeCircleX(0))
            .endAngle(gaugeCircleX(1))
            .outerRadius(gaugeCircleY(radius))
            .innerRadius(gaugeCircleY(radius - circleThickness));
        gaugeGroup.append("path")
            .attr("d", gaugeCircleArc)
            .style("fill", config.circleColor)
            .attr("opacity", config.opacity)
            .attr('transform', 'translate(' + radius + ',' + radius + ')');
        // Text where the wave does not overlap.
        gaugeGroup.append("text")
            .text(format(textStartValue) + percentText)
            .attr("class", "liquidFillGaugeText")
            .attr("font-family", config.font)
            .attr("text-anchor", "middle")
            .attr("font-size", textPixels + "px")
            .style("fill", config.textColor)
            .attr('transform', 'translate(' + radius + ',' + textRiseScaleY(config.textVertPosition) + ')');
        // The clipping wave area.
        var clipArea = d3.area()
            .x(function (d) { return waveScaleX(d.x); })
            .y0(function (d) { return waveScaleY(Math.sin(Math.PI * 2 * config.waveOffset * -1 + Math.PI * 2 * (1 - config.waveCount) + d.y * 2 * Math.PI)); })
            .y1(function (d) { return (fillCircleRadius * 2 + waveHeight); });
        var waveGroup = gaugeGroup.append("defs")
            .append("clipPath")
            .attr("id", "clipWave" + elementId);
        var wave = waveGroup.append("path")
            .datum(data)
            .attr("d", clipArea)
            .attr("T", 0);
        // The inner circle with the clipping wave attached.
        var fillCircleGroup = gaugeGroup.append("g")
            .attr("clip-path", "url(" + location.href + "#clipWave" + elementId + ")");
        fillCircleGroup.append("circle")
            .attr("cx", radius)
            .attr("cy", radius)
            .attr("r", fillCircleRadius)
            .style("fill", config.waveColor)
            .attr("opacity", config.opacity);
        // Text where the wave does overlap.
        fillCircleGroup.append("text")
            .text(format(textStartValue))
            .attr("class", "liquidFillGaugeText")
            .attr("font-family", config.font)
            .attr("text-anchor", "middle")
            .attr("font-size", textPixels + "px")
            .style("fill", config.waveTextColor)
            .attr('transform', 'translate(' + radius + ',' + textRiseScaleY(config.textVertPosition) + ')');
        // Make the value count up.
        if (config.valueCountUp) {
            gaugeGroup.selectAll("text.liquidFillGaugeText").transition()
                .duration(config.waveRiseTime)
                .tween("text", function (d) {
                var that = d3.select(this);
                var i = d3.interpolateNumber(that.text().replace("%", ""), textFinalValue);
                return function (t) { that.text(format(i(t)) + percentText); };
            });
        }
        // Make the wave rise. wave and waveGroup are separate so that horizontal and vertical movement
        // can be controlled independently.
        var waveGroupXPosition = fillCircleMargin + fillCircleRadius * 2 - waveClipWidth;
        if (config.waveRise) {
            waveGroup.attr('transform', 'translate(' + waveGroupXPosition + ',' + waveRiseScale(0) + ')')
                .transition()
                .duration(config.waveRiseTime)
                .attr('transform', 'translate(' + waveGroupXPosition + ',' + waveRiseScale(fillPercent) + ')')
                .on("start", function () { wave.attr('transform', 'translate(1,0)'); });
            // This transform is necessary to get the clip wave positioned correctly when
            // waveRise=true and waveAnimate=false. The wave will not position correctly without
            // this, but it's not clear why this is actually necessary.
        }
        else {
            waveGroup.attr('transform', 'translate(' + waveGroupXPosition + ',' + waveRiseScale(fillPercent) + ')');
        }
        if (config.waveAnimate)
            animateWave();
        function animateWave() {
            wave.attr('transform', 'translate(' + waveAnimateScale(wave.attr('T')) + ',0)');
            wave.transition()
                .duration(config.waveAnimateTime * (1 - wave.attr('T')))
                .ease(d3.easeLinear)
                .attr('transform', 'translate(' + waveAnimateScale(1) + ',0)')
                .attr('T', 1)
                .on('end', function () {
                wave.attr('T', 0);
                animateWave();
            });
        }
        function GaugeUpdater() {
            this.setWaveAnimate = function (value) {
                // Note: must call update after setting value
                config.waveAnimate = value;
            };
            this.update = function (value) {
                var fillPercent = Math.max(config.minValue, Math.min(config.maxValue, value)) / config.maxValue;
                gaugeGroup.selectAll("text.liquidFillGaugeText").transition()
                    .duration(config.waveRiseTime)
                    .tween("text", function (d) {
                    var that = d3.select(this);
                    var i = d3.interpolateNumber(that.text().replace("%", ""), fillPercent * 100);
                    return function (t) { that.text(format(i(t)) + percentText); };
                });
                var waveHeight = fillCircleRadius * waveHeightScale(fillPercent * 100);
                var waveRiseScale = d3.scaleLinear()
                    // The clipping area size is the height of the fill circle + the wave height, so we position
                    // the clip wave such that the it will overlap the fill circle at all when at 0%, and will
                    // totally cover the fill circle at 100%.
                    .range([(fillCircleMargin + fillCircleRadius * 2 + waveHeight), (fillCircleMargin - waveHeight)])
                    .domain([0, 1]);
                var newHeight = waveRiseScale(fillPercent);
                var waveScaleX = d3.scaleLinear().range([0, waveClipWidth]).domain([0, 1]);
                var waveScaleY = d3.scaleLinear().range([0, waveHeight]).domain([0, 1]);
                var newClipArea;
                if (config.waveHeightScaling) {
                    newClipArea = d3.area()
                        .x(function (d) { return waveScaleX(d.x); })
                        .y0(function (d) {
                        return waveScaleY(Math.sin(Math.PI * 2 * config.waveOffset * -1 + Math.PI * 2 * (1 - config.waveCount) + d.y * 2 * Math.PI));
                    })
                        .y1(function (d) { return (fillCircleRadius * 2 + waveHeight); });
                }
                else {
                    newClipArea = clipArea;
                }
                var newWavePosition = config.waveAnimate ? waveAnimateScale(1) : 0;
                wave.transition()
                    .duration(0)
                    .transition()
                    .duration(config.waveAnimate ? (config.waveAnimateTime * (1 - wave.attr('T'))) : config.waveRiseTime)
                    .ease(d3.easeLinear)
                    .attr('d', newClipArea)
                    .attr('transform', 'translate(' + newWavePosition + ',0)')
                    .attr('T', '1')
                    .on("end", function () {
                    if (config.waveAnimate) {
                        wave.attr('transform', 'translate(' + waveAnimateScale(0) + ',0)');
                        animateWave();
                    }
                });
                waveGroup.transition()
                    .duration(config.waveRiseTime)
                    .attr('transform', 'translate(' + waveGroupXPosition + ',' + newHeight + ')');
            };
        }
        return new GaugeUpdater();
    }

    return default_1;

});
